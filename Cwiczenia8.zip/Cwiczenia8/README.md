# Ćwiczenia6

Zadanie do rozwiązania znajdują się w klasie `LinqTasks.cs`. Zadania należy rozwiązać za pomocą składni LINQ.

## Testy
Do zadania zostały dodane testy, które wskazują czy poprawnie rozwiązaliśmy dany `TaskX`. 
